//
//  ReadView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI
import Foundation

struct ReadView: View {
    @StateObject var viewModel = ReadViewModel()
    
    var body: some View {
        
        NavigationStack{
            
            ScrollView {
                VStack{
                    if viewModel.value != nil{
                        Text(viewModel.value!)
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                    }
                    else{
                        Text("Value")
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                    }
                    
                    Button{
                        viewModel.readValue()
                    }label:{
                        Image(systemName: "square.and.arrow.up.on.square")
                            .foregroundStyle(Color.primary)
                        Text("Read Value")
                            .foregroundStyle(Color.primary)
                    }
                    .padding(20)
                    .background(Color.accentColor)
                    .clipShape(Capsule())
                    
                    
                    if viewModel.object != nil{
                        Text(viewModel.object!.id)
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                        
                        Text(viewModel.object!.value)
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                    }
                    else{
                        Text("Value")
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                    }
                    
                    Button{
                        viewModel.readObject()
                    }label:{
                        Image(systemName: "square.and.arrow.up.on.square")
                            .foregroundStyle(Color.primary)
                        Text("Read Object")
                            .foregroundStyle(Color.primary)
                    }
                    .padding(20)
                    .background(Color.accentColor)
                    .clipShape(Capsule())
                    
                    if !viewModel.listObject.isEmpty {
                        VStack{
                            ForEach(viewModel.listObject, id: \.self){ object in
                                Text(object.id)
                                    .foregroundStyle(Color.primary)
                                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                                    .background(Color.secondary)
                                
                                Text(object.value)
                                    .foregroundStyle(Color.primary)
                                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                                    .background(Color.secondary)
                        }
                       
                        }
                    }
                    else{
                        Text("Value")
                            .foregroundStyle(Color.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                            .background(Color.secondary)
                    }
                    
                    Button{
                        viewModel.observeListObject()
                    }label:{
                        Image(systemName: "square.and.arrow.up.on.square")
                            .foregroundStyle(Color.primary)
                        Text("Read List of Objects")
                            .foregroundStyle(Color.primary)
                    }
                    .padding(20)
                    .background(Color.accentColor)
                    .clipShape(Capsule())
                }
            }
        }
        .onAppear(){
//            viewModel.readObject()
//            viewModel.observeListObject()
        }
    }
        
}

#Preview {
    ReadView()
}
