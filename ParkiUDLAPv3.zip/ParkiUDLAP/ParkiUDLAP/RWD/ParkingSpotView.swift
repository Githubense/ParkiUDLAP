//
//  ParkingSpotView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 12/04/24.
//

import SwiftUI

struct ParkingSpotView: View {
    @StateObject var viewModel = ReadViewModel()
    
    var body: some View {
        NavigationStack{
            
            if viewModel.value != nil{
                Rectangle()
                    .fill(viewModel.value != "0" ? Color.green : Color.red)
                    .frame(width: 200, height: 200)
                Text(viewModel.value!)
                    .foregroundStyle(Color.primary)
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                    .background(Color.secondary)
            }
            else{
                Text("Value")
                    .foregroundStyle(Color.primary)
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                    .background(Color.secondary)
            }
        }.onAppear(){
            viewModel.observerDataChange()
        }
    }
}

#Preview {
    ParkingSpotView()
}
