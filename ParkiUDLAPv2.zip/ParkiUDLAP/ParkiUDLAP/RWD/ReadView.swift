//
//  ReadView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI
import Foundation

struct ReadView: View {
    @StateObject var viewModel
    
    var body: some View {
        VStack{
            Text("Value")
                .foregroundStyle(Color.primary)
                .background(Color.secondary)
            
            Button{
                
            }label:{
                Image(systemName: "square.and.arrow.up.on.square")
                    .foregroundStyle(Color.primary)
                Text("Read")
                    .foregroundStyle(Color.primary)
            }
            .padding(20)
            .background(Color.accentColor)
            .clipShape(Capsule())
        }
    }
}

#Preview {
    ReadView()
}
