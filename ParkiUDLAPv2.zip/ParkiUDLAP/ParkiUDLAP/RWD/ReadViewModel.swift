//
//  ReadViewModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import Foundation
import FirebaseDatabase
import FirebaseDatabaseSwift

class ReadViewModel: ObservableObject{
    
    var
}
