//
//  ObjectModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import Foundation

class ObjectModel: Encodable{
    var id: String = ""
    var value: String = ""
}

extension Encodable{
    var toDictionary: [String: Any]?{
        guard let data = try? JSONEncoder().encode(self) else {
            return nil
        }
        
        return try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
    }
}
