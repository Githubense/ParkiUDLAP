//
//  HomeView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 15/04/24.
//

import SwiftUI

struct HomeView: View {

    @State var selectedCategory = "Coche"
    @Environment(\.presentationMode) var mode

    var body: some View {
        NavigationStack {
            ScrollView {
                ZStack {
                    VStack {
                        HStack {
                            NavigationLink{
                                ProfileView()
                            }label:{
                                ProfileViewButton()
                            }
                            Spacer()
                            NotificationBellButton()
                        }
                        .padding(.horizontal,13)
                        .padding(.top,13)
                        .padding(.bottom, 5)
                        SearchBar()
                        
                        Text("Categoria")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .font(.system(size:25))
                            .bold()
                            .foregroundStyle(Color.udlapGreen)
                            .padding(.leading,20)
                        
                        CategoryListView
                        
                        Text("Recientes")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .font(.system(size:25))
                            .bold()
                            .foregroundStyle(Color.udlapGreen)
                            .padding(.leading,20)
                        
                        ForEach(parkList, id: \.id) { item in
                            ParkCard(park: item)
                        }
    //
    //                                // Search bar
    //                                  SearchBar()
    //
    //                                // Categories
    //                                ScrollView(.horizontal, showsIndicators: false) {
    //                                    HStack {
    //                                        CategoryButton(imageName: "car.fill", category: "Coche")
    //                                        CategoryButton(imageName: "scooter", category: "Moto")
    //                                        CategoryButton(imageName: "bicycle", category: "Bicicleta")
    //                                        CategoryButton(imageName: "truck.box.fill", category: "Camion")
    //                                    }
    //                                }
    //                                
    //                                // Recent locations
    //                                List {
    //                                    RecentLocation(name: "Text 5", spaces: 0, imageName: "location1")
    //                                    RecentLocation(name: "Text 8", spaces: 0, imageName: "location2")
    //                                    RecentLocation(name: "Estacionamiento 13", spaces: 0, imageName: "location3")
    //                                }
    //                                
    //                                Spacer()
    //                                // Bottom navigation bar
                        
                    }
                }
            }
        }
    }
    var CategoryListView: some View {
        HStack{
                HStack{
                    ForEach(categoryList, id: \.id) { item in
                        Button{
                            selectedCategory = item.title
                        }label:{
                            VStack{
                                Image(systemName: item.image)
                                    .font(.system(size: 20, weight: .bold))
                                    .frame(alignment: .center)
                                Text(item.title)
                            }
                            .frame(width:80, height: 80)
                            .background(selectedCategory == item.title ?.udlapOrange:.gray.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 13))
                            .foregroundColor(selectedCategory != item.title ? .gray: .white)
                        }
                    }
                }
        }
    }
}

// Product Card View
struct ParkCard: View{
    var park: Park
    var body: some View{
        
        NavigationLink{
            ParkingSpotView(park: park)
        }
        label:{

            ZStack{
                HStack{
                    Image(park.image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 85,height: 70)
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                        .padding(.leading, 10)
                    VStack(alignment: .leading){
                        Text("\(park.name)")
                            .font(.system(size: 25, weight: .semibold))
                            .foregroundStyle(Color.udlapGreen)
                        
                        Text("\(park.name)")
                            .font(.system(size: 20, weight: .regular))
                            .foregroundStyle(Color.udlapOrange)
                        
                    }
                    
                    Spacer()
                    VStack(){
                        Text("Espacios")
                            .font(.system(size: 15, weight: .regular))
                            .foregroundStyle(Color.udlapOrange)
                        
                        Text("10")
                            .font(.system(size: 20, weight: .regular))
                            .foregroundStyle(Color.udlapOrange)
                    }.padding(.trailing)
                }
                .frame(width:350, height: 95)
            }
        .frame(width: 350, height: 95)
        .background(Color.gray.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
        .padding(3)
        }
    }
}


struct ProfileViewButton: View {
    var body: some View {
        HStack {
            Image("pimienta")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 40, height: 40)
                .clipShape(Circle())
            VStack(alignment: .leading) {
                Text("Angel Pimienta")
                    .foregroundStyle(Color.udlapGreen)
                    .font(.system(size: 18))
                    .fontWeight(.bold)
                Text("Alumno")
                    .foregroundStyle(Color.udlapOrange)
                    .font(.system(size: 12))
                    .fontWeight(.semibold)
            }
            Spacer()
        }
        .padding(.horizontal, 5)
        .frame(width: 225, height: 50)
        .background(Color.udlapSoftGray)
        .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
    }
}

// Notification Bell
struct NotificationBellButton: View {
    var body: some View {
        Image(systemName: "bell")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 30, height: 30)
            .padding(.horizontal)
    }
}

// Search Bar
struct SearchBar: View {
    @State private var searchText = ""
    var body: some View {
        TextField("\(Image(systemName: "magnifyingglass"))  Buscar Estacionamientos...", text: $searchText)
            .padding()
            .background(Color.gray.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
            .padding(.horizontal,13)
    }
}

// Category Button
struct CategoryButton: View {
    var imageName: String
    var category: String
    
    var body: some View {
        VStack {
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 50, height: 50)
            
            Text(category)
                .font(.caption)
                .padding(.top, 5)
        }
        .padding(.horizontal)
    }
}

// Recent Location
struct RecentLocation: View {
    var name: String
    var spaces: Int
    var imageName: String
    
    var body: some View {
        HStack {
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
            
            Spacer().frame(width: CGFloat(spaces * 10))
            
            Text(name)
            
            Spacer()
        }
        .padding()
    }
}

#Preview {
    HomeView()
}
