//
//  RootView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 12/04/24.
//

import SwiftUI

struct RootView: View {
    var body: some View {
        
        NavigationStack {
            TabView{
                HomeView()
                    .tabItem{
                        Image(systemName:"house.fill")
                        Text("Inicio")
                    }
                MapView()
                    .tabItem{
                        Image(systemName:"map.fill")
                        Text("Mapa")
                    }
//                QRView()
//                    .tabItem {
//                        Image(systemName: "qrcode")
//                        Text("QR")
//                    }
                ServicesView()
                    .tabItem{
                        Image(systemName:"square.grid.2x2.fill")
                        Text("Servicios")
                    }
                HomeView()
                    .tabItem{
                        Image(systemName:"ellipsis")
                        Text("Más")
                    }
            }
            .accentColor(.udlapOrange)
        }
    }
}

#Preview {

    RootView()
}
