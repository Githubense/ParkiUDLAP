//
//  BranchesModel.swift
//  restaurant
//
//  Created by pmienta on 01/02/24.
//

//Data struct model for Branches

import SwiftUI

struct Park: Identifiable {
    var id: UUID = .init()
    var name: String
    var address: String
    var image: String
    var star: Int
    var color: Color
    var description: String
    var number: Int
}

var parkList = [
    Park(name: "Negocios", address: "E01", image:"negocios", star:5, color: .yellow, description: "2PM - 10PM", number:5586762914),
    Park(name: "Biblioteca", address: "E02", image:"biblio", star:4, color: .red, description: "2PM - 7PM", number:2222839578),
    Park(name: "Bernal", address: "E03", image:"bernal", star:5, color: .green, description: "2PM - 10PM", number:5586762914),
    Park(name: "Cain-Murray", address: "E04", image:"cain", star:3, color: .brown, description: "2PM - 7PM", number:5586762914),
]

