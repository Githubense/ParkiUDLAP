//
//  QRView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 17/04/24.
//

import SwiftUI

struct QRView: View {
    var body: some View {
        Text("QR VIew")
    }
}

#Preview {
    QRView()
}
