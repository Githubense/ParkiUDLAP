//
//  ContentView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RootView()
    }
}

#Preview {
    ContentView()
}
