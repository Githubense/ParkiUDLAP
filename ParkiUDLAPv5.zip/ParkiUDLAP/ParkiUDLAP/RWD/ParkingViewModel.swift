//
//  ReadViewModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import Foundation
import FirebaseDatabase
import FirebaseDatabaseSwift

class ParkingViewModel: ObservableObject{
    
    var ref = Database.database().reference()

    @Published var value: String? = nil
    @Published var object: ParkingModel? = nil
    @Published var listObject = [ObjectModel]()

//    func readValue(){
//        ref.child("KeyA").observeSingleEvent(of: .value){ snapshot in
//            self.value = snapshot.p1 as? String ?? "Load failed"
//        }
//    }
//    
//    func observerDataChange(){
//        ref.child("KeyA").observe(.value) { snapshot in
//            self.value = snapshot.value as? String ?? "Load failed"
//        }
//    }
//    
    func readObject(){
        ref.child("E01").observe(.value){ snapshot in
            do{
                self.object = try snapshot.data(as: ParkingModel.self)
            }
            catch{
                print("Cannot convert to ObjectModel")
            }
        }
    }
    
    func readPark(parkName: String){
        ref.child(parkName).observe(.value){ snapshot in
            do{
                self.object = try snapshot.data(as: ParkingModel.self)
            }
            catch{
                print("Cannot convert to ObjectModel")
            }
        }
    }
//
//    func observeListObject(){
//        ref.observe(.value) { parentSnapshot in
//            guard let children = parentSnapshot.children.allObjects as? [DataSnapshot] else{
//                return
//            }
//            self.listObject = children.compactMap({snapshot in
//                return try? snapshot.data(as: ObjectModel.self)
//            })
//        }
//    }
}
