//
//  MapView.swift
//  ParkiUDLAP
//
//  Created by Doris Elena  on 15/04/24.
//

import SwiftUI

struct MapView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    MapView()
}
