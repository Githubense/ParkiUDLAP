//
//  WriteViewModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI
import Foundation
import FirebaseDatabase
import FirebaseDatabaseSwift

class WriteViewModel: ObservableObject{
    
    private let ref = Database.database().reference()
    
    func pushNewValue(value:Int){
        ref.setValue(value)
    }
}
