//
//  WriteView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI
import Foundation


struct WriteView: View {
    @StateObject var viewModel = WriteViewModel()
    @State private var content = 0
    let formatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        return formatter
    }()
    
    var body: some View {
        VStack{
            TextField("Enter value", value: $content, formatter: formatter)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.decimalPad)
                .padding()

            Button{
                viewModel.pushNewValue(value: content)
            }label:{
                Image(systemName: "arrow.up.circle")
                    .foregroundStyle(Color.primary)
                Text("Push")
                    .foregroundStyle(Color.primary)
            }
            .padding(20)
            .background(Color.accentColor)
            .clipShape(Capsule())
        }
    }
}

#Preview {
    WriteView()
}
