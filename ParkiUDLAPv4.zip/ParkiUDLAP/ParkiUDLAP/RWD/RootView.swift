//
//  RootView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 12/04/24.
//

import SwiftUI

struct RootView: View {
    var body: some View {
        VStack{
            
            NavigationLink{
                WriteView()
            }label:{
                Image(systemName: "square.and.arrow.up")
                    .foregroundStyle(Color.primary)
                Text("Write")
                    .foregroundStyle(Color.primary)
            }
            .padding(20)
            .background(Color.accentColor)
            .clipShape(Capsule())
            
            
            NavigationLink{
                ReadView()
            }label:{
                Image(systemName: "square.and.arrow.up")
                    .foregroundStyle(Color.primary)
                Text("Read")
                    .foregroundStyle(Color.primary)
            }
            .padding(20)
            .background(Color.accentColor)
            .clipShape(Capsule())
            
            NavigationLink{
                ParkingSpotView()
            }label:{
                Image(systemName: "car.side")
                    .foregroundStyle(Color.primary)
                Text("Parking")
                    .foregroundStyle(Color.primary)
            }
            .padding(20)
            .background(Color.accentColor)
            .clipShape(Capsule())
            
        }
    }
}

#Preview {

    RootView()
}
