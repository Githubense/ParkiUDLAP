//
//  ParkingSpotView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 12/04/24.
//

import SwiftUI

struct ParkingSpotView: View {
    @StateObject var viewModel = ParkingViewModel()
    
    var body: some View {
        NavigationStack{
//            if viewModel.value != nil{
//                Rectangle()
//                    .fill(viewModel.value != "0" ? Color.green : Color.red)
//                    .frame(width: 200, height: 200)
//                Text(viewModel.value!)
//                    .foregroundStyle(Color.primary)
//                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
//                    .background(Color.secondary)
//            }
//            else{
//                Text("Value")
//                    .foregroundStyle(Color.primary)
//                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
//                    .background(Color.secondary)
//            }
            
                                if viewModel.object != nil{
                                    VStack{
                                        Rectangle()
                                            .fill(viewModel.object!.p1 != "0" ? Color.green : Color.red)
                                            .frame(width: 200, height: 100)
                                        
                                        Rectangle()
                                            .fill(viewModel.object!.p2 != "0" ? Color.green : Color.red)
                                            .frame(width: 200, height: 100)
                                        
                                        Rectangle()
                                            .fill(viewModel.object!.p3 != "0" ? Color.green : Color.red)
                                            .frame(width: 200, height: 100)
                                        
                                        Rectangle()
                                            .fill(viewModel.object!.p4 != "0" ? Color.green : Color.red)
                                            .frame(width: 200, height: 100)
                                    }
                                    

                                    
                                }
                                else{
                                    Text("Value")
                                        .foregroundStyle(Color.primary)
                                        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                                        .background(Color.secondary)
                                }
            
                                Button{
                                    viewModel.readObject()
                                }label:{
                                    Image(systemName: "square.and.arrow.up.on.square")
                                        .foregroundStyle(Color.primary)
                                    Text("Read Object")
                                        .foregroundStyle(Color.primary)
                                }
                                .padding(20)
                                .background(Color.accentColor)
                                .clipShape(Capsule())
        }.onAppear(){
            viewModel.readObject()
        }
    }
}

#Preview {
    ParkingSpotView()
}
