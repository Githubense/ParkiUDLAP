//
//  HomeView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 15/04/24.
//

import SwiftUI

struct HomeView: View {
    @State private var selection = 0

    var body: some View {
        
        VStack {
                        // Profile and notification icons
                        HStack {
                            ProfileView()
                            Spacer()
                            NotificationBell()
                        }
                        .padding()
                        
                        // Search bar
                        SearchBar()
                        
                        // Categories
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                CategoryButton(imageName: "car.fill", category: "Coche")
                                CategoryButton(imageName: "scooter", category: "Moto")
                                CategoryButton(imageName: "bicycle", category: "Bicicleta")
                                CategoryButton(imageName: "truck.box.fill", category: "Camion")
                            }
                        }
                        
                        // Recent locations
                        List {
                            RecentLocation(name: "Text 5", spaces: 0, imageName: "location1")
                            RecentLocation(name: "Text 8", spaces: 0, imageName: "location2")
                            RecentLocation(name: "Estacionamiento 13", spaces: 0, imageName: "location3")
                        }
                        
                        Spacer()
                        // Bottom navigation bar
                    }
                }
    }



struct ProfileView: View {
    var body: some View {
        HStack {
            Image(systemName: "person.circle")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
            
            VStack(alignment: .leading) {
                Text("John Doe")
                    .font(.headline)
                Text("johndoe@example.com")
                    .font(.subheadline)
            }
            
            Spacer()
        }
        .padding(.horizontal)
    }
}

// Notification Bell
struct NotificationBell: View {
    var body: some View {
        Image(systemName: "bell")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 30, height: 30)
            .padding(.horizontal)
    }
}

// Search Bar
struct SearchBar: View {
    @State private var searchText = ""
    
    var body: some View {
        TextField("Search", text: $searchText)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .padding(.horizontal)
            .padding(.top)
    }
}

// Category Button
struct CategoryButton: View {
    var imageName: String
    var category: String
    
    var body: some View {
        VStack {
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 50, height: 50)
            
            Text(category)
                .font(.caption)
                .padding(.top, 5)
        }
        .padding(.horizontal)
    }
}

// Recent Location
struct RecentLocation: View {
    var name: String
    var spaces: Int
    var imageName: String
    
    var body: some View {
        HStack {
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
            
            Spacer().frame(width: CGFloat(spaces * 10))
            
            Text(name)
            
            Spacer()
        }
        .padding()
    }
}

#Preview {
    HomeView()
}
